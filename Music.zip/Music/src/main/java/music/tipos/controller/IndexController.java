package music.tipos.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
	
	@RequestMapping("/")
	public String index() {
		return "index";		
	}
	
	@RequestMapping("/exemplo")
	public String ex() {
		return "exemplo";
	}
	
	@RequestMapping("/blog")
	public String blog() {
		return "blog";
	}
	

}
